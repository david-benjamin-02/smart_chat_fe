// import React from 'react';
// import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
// import Editor from './components/Editor';

// function App() {
//   return (
//     <Router>
//       <Routes>
//         <Route path="/editor/:docId" element={<Editor />} />
//         <Route path="*" element={<Navigate to={`/editor/123`} />} />
//       </Routes>
//     </Router>
//   );
// }

// export default App;